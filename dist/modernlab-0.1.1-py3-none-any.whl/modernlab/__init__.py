from quick_plot import *
from variational_error import *