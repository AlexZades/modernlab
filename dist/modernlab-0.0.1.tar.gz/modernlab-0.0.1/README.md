# modernlab
Library of python scripts to help with data analysis  
check the [wiki on github](https://github.com/AlexZades/modernlab/wiki/) for help 
